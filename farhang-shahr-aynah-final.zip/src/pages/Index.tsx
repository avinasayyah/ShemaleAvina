import BookingSystem from '../components/BookingSystem';

const Index = () => {
  return <BookingSystem />;
};

export default Index;
