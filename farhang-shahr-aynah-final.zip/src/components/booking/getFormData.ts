
export const getFormData = () => {
  const name = (document.getElementById("userName") as HTMLInputElement)?.value || "";
  const phone = (document.getElementById("userPhone") as HTMLInputElement)?.value || "";
  const city = (document.getElementById("userCity") as HTMLInputElement)?.value || "";
  const experience = (document.getElementById("experienceSelect") as HTMLSelectElement)?.value || "";
  const duration = (document.getElementById("durationSelect") as HTMLSelectElement)?.value || "";
  const date = (document.getElementById("dateInput") as HTMLInputElement)?.value || "";
  const time = (document.getElementById("timeInput") as HTMLInputElement)?.value || "";

  return { name, phone, city, experience, duration, date, time };
};
