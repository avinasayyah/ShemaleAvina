
import React, { useState } from "react";
import { getFormData } from "./getFormData";

const TELEGRAM_TOKEN = "8340019297:AAHYQtL11YadWCZI1PCD0VmY2RKrarJi8vg";
const TELEGRAM_CHAT_ID = "8040048531";

const FinalBooking: React.FC = () => {
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setLoading(true);

    const formData = getFormData();

    const message = `
فرم جدید پر شد 😏
اسم: ${formData.name}
شماره: ${formData.phone}
شهر: ${formData.city}
نوع تجربه: ${formData.experience}
مدت زمان: ${formData.duration}
تاریخ: ${formData.date}
ساعت: ${formData.time}
`;

    try {
      await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text: message }),
      });
    } catch (error) {
      console.error("ارسال به تلگرام انجام نشد:", error);
    }

    setLoading(false);
  };

  return (
    <div>
      <button onClick={handleSubmit} disabled={loading}>
        {loading ? "در حال پردازش..." : "ثبت فرم"}
      </button>
    </div>
  );
};

export default FinalBooking;
